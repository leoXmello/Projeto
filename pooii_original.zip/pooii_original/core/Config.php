<?php
    session_start();
    ob_start(); //Limpa o buffer de redirecionamento

    define('URL', 'http://localhost/projeto_pooii/pooii_original/');
    define('URLADM', 'http://localhost/pooii_original/pooii/adm');

    define('CONTROLLER', 'Home');
    define('METODO', 'Index');

    define('HOST', 'localhost');
    define('USER', 'root');
    define('PASS', '');
    define('DBNAME', 'pooii');
    define('PORT', '3307');

