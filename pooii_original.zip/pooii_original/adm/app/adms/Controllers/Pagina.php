<?php

namespace Adms\Controllers;

class Pagina
{
    public function Index(){

    }
}