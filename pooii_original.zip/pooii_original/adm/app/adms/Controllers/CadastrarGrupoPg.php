<?php

namespace Adms\Controllers;

class CadastrarGrupoPg
{
    public function Index(){

    }
}