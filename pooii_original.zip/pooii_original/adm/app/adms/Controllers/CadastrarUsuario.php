<?php

namespace Adms\Controllers;

class CadastrarUsuario
{
    public function Index(){

    }
}