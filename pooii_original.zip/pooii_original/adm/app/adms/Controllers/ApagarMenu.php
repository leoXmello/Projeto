<?php

namespace Adms\Controllers;

class ApagarMenu
{
    public function Index(){

    }
}