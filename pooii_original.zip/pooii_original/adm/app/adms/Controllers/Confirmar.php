<?php

namespace Adms\Controllers;

class Confirmar
{
    public function Index(){

    }
}