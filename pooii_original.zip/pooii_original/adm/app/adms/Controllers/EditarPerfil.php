<?php

namespace Adms\Controllers;

class EditarPerfil
{
    public function Index(){

    }
}