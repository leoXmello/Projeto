<?php

namespace Adms\Controllers;

class VerSitUser
{
    public function Index(){

    }
}