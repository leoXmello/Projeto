<?php

namespace Adms\Controllers;

class VerUsuario
{
    public function Index(){

    }
}