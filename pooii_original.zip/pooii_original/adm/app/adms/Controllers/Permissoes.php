<?php

namespace Adms\Controllers;

class Permissoes
{
    public function Index(){

    }
}