<?php

namespace Adms\Controllers;

class ApagarNivAc
{
    public function Index(){

    }
}