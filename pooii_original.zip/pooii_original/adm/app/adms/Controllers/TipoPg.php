<?php

namespace Adms\Controllers;

class TipoPg
{
    public function Index(){

    }
}