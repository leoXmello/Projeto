<?php

namespace Adms\Controllers;

class EditarCor
{
    public function Index(){

    }
}