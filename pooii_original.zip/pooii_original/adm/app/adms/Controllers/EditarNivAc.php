<?php

namespace Adms\Controllers;

class EditarNivAc
{
    public function Index(){

    }
}