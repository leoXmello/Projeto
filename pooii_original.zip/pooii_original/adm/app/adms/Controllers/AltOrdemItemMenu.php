<?php

namespace Adms\Controllers;

class AltOrdemItemMenu
{
    public function Index(){

    }
}