<?php

namespace Adms\Controllers;

class CadastrarCor
{
    public function Index(){

    }
}