<?php

namespace Adms\Controllers;

class Login
{
    public function Index(){

    }
}