<?php

namespace Adms\Controllers;

class CadastrarPagina
{
    public function Index(){

    }
}