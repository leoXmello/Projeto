<?php

namespace Adms\Controllers;

class NivelAcesso
{
    public function Index(){

    }
}