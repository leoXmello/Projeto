<?php

namespace Adms\Controllers;

class AtualSenha
{
    public function Index(){

    }
}