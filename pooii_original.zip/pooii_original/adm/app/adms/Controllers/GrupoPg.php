<?php

namespace Adms\Controllers;

class GrupoPg
{
    public function Index(){

    }
}