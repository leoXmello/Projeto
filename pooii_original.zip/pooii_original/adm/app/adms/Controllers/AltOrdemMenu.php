<?php

namespace Adms\Controllers;

class AltOrdemMenu
{
    public function Index(){

    }
}