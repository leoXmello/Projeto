<?php

namespace Adms\Controllers;

class ApagarSit
{
    public function Index(){

    }
}