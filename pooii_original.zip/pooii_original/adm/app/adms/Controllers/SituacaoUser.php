<?php

namespace Adms\Controllers;

class SituacaoUser
{
    public function Index(){

    }
}