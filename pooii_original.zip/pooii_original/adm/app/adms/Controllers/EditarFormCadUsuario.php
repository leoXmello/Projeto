<?php

namespace Adms\Controllers;

class EditarFormCadUsuario
{
    public function Index(){

    }
}