<?php

namespace Adms\Controllers;

class CadastrarSitPg
{
    public function Index(){

    }
}