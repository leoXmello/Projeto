<?php

namespace Adms\Controllers;

class VerGrupoPg
{
    public function Index(){

    }
}