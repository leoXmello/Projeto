<?php

namespace Adms\Controllers;

class AlterarSenha
{
    public function Index(){

    }
}