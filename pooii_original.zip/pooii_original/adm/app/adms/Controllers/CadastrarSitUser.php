<?php

namespace Adms\Controllers;

class CadastrarSitUser
{
    public function Index(){

    }
}