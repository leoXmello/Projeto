<?php

namespace Adms\Controllers;

class EditarUsuario
{
    public function Index(){

    }
}