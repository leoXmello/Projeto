<?php

namespace Adms\Controllers;

class Home
{
    public function Index(){

    }
}