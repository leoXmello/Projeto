<?php

namespace Adms\Controllers;

class AltOrdemGrupoPg
{
    public function Index(){

    }
}