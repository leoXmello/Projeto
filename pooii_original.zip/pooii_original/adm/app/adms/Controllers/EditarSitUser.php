<?php

namespace Adms\Controllers;

class EditarSitUser
{
    public function Index(){

    }
}