<?php

namespace Adms\Controllers;

class EditarMenu
{
    public function Index(){

    }
}