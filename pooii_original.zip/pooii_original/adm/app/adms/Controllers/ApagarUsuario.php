<?php

namespace Adms\Controllers;

class ApagarUsuario
{
    public function Index(){

    }
}