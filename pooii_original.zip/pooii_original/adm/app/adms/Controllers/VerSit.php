<?php

namespace Adms\Controllers;

class VerSit
{
    public function Index(){

    }
}