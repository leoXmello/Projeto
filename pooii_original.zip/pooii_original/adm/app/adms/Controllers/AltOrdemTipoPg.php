<?php

namespace Adms\Controllers;

class AltOrdemTipoPg
{
    public function Index(){

    }
}