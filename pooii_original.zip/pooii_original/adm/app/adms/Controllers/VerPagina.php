<?php

namespace Adms\Controllers;

class VerPagina
{
    public function Index(){

    }
}