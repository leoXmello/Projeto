<?php

namespace Adms\Controllers;

class SincroPgNivAc
{
    public function Index(){

    }
}