<?php

namespace Adms\Controllers;

class CadastrarMenu
{
    public function Index(){

    }
}