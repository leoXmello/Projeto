<?php

namespace Adms\Controllers;

class VerCor
{
    public function Index(){

    }
}