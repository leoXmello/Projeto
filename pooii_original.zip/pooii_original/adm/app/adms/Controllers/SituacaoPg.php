<?php

namespace Adms\Controllers;

class SituacaoPg
{
    public function Index(){

    }
}