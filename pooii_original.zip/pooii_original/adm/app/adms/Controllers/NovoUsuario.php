<?php

namespace Adms\Controllers;

class NovoUsuario
{
    public function Index(){

    }
}