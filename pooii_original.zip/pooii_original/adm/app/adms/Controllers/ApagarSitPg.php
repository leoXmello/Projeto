<?php

namespace Adms\Controllers;

class ApagarSitPg
{
    public function Index(){

    }
}