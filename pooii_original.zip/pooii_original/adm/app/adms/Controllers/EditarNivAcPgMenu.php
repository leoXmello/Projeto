<?php

namespace Adms\Controllers;

class EditarNivAcPgMenu
{
    public function Index(){

    }
}