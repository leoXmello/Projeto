<?php

namespace Adms\Controllers;

class Menu
{
    public function Index(){

    }
}