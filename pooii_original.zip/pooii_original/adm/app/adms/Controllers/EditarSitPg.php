<?php

namespace Adms\Controllers;

class EditarSitPg
{
    public function Index(){

    }
}