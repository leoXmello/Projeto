<?php

namespace Adms\Controllers;

class EditarTipoPg
{
    public function Index(){

    }
}