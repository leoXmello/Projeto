<?php

namespace Adms\Controllers;

class ApagarTipoPg
{
    public function Index(){

    }
}