<?php

namespace Adms\Controllers;

class EditarSit
{
    public function Index(){

    }
}