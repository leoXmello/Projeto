<?php

namespace Adms\Controllers;

class ApagarCor
{
    public function Index(){

    }
}