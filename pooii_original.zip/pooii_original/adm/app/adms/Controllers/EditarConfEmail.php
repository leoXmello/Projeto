<?php

namespace Adms\Controllers;

class EditarConfEmail
{
    public function Index(){

    }
}