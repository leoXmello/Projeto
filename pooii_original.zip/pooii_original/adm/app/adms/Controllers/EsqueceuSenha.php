<?php

namespace Adms\Controllers;

class EsqueceuSenha
{
    public function Index(){

    }
}