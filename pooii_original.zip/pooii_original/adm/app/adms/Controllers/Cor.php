<?php

namespace Adms\Controllers;

class Cor
{
    public function Index(){

    }
}