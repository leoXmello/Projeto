<?php

namespace Adms\Controllers;

class ApagarSitUser
{

}