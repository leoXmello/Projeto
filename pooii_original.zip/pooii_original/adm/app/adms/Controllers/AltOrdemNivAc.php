<?php

namespace Adms\Controllers;

class AltOrdemNivAc
{
    public function Index(){

    }
}