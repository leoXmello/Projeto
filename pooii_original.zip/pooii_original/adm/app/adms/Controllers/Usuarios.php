<?php

namespace Adms\Controllers;

class Usuarios
{
    public function Index(){

    }
}