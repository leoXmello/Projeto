<?php

namespace Adms\Controllers;

class EditarGrupoPg
{
    public function Index(){

    }
}