<?php

namespace Adms\Controllers;

class Situacao
{
    public function Index(){

    }
}