<?php

namespace Adms\Controllers;

class ApagarPagina
{
    public function Index(){

    }
}