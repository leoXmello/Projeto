<?php

namespace Adms\Controllers;

class VerNivAc
{
    public function Index(){

    }
}