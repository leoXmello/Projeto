<?php

namespace Adms\Controllers;

class CadastrarNivAc
{
    public function Index(){

    }
}