<?php

namespace Adms\Controllers;

class LibMenu
{
    public function Index(){

    }
}