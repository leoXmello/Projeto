<?php

namespace Adms\Controllers;

class CadastrarSit
{
    public function Index(){

    }
}