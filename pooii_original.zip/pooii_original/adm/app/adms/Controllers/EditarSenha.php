<?php

namespace Adms\Controllers;

class EditarSenha
{
    public function Index(){

    }
}