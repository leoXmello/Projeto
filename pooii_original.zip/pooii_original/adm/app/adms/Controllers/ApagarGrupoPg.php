<?php

namespace Adms\Controllers;

class ApagarGrupoPg
{
    public function Index(){

    }
}