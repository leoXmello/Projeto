<?php

namespace Adms\Controllers;

class CadastrarTipoPg
{
    public function Index(){

    }
}