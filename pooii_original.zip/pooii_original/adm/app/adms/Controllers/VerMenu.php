<?php

namespace Adms\Controllers;

class VerMenu
{
    public function Index(){

    }
}