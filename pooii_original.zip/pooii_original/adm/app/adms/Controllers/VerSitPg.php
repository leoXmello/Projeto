<?php

namespace Adms\Controllers;

class VerSitPg
{
    public function Index(){

    }
}