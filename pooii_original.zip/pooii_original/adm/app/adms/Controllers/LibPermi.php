<?php

namespace Adms\Controllers;

class LibPermi
{
    public function Index(){

    }
}