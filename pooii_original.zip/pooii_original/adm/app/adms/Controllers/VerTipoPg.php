<?php

namespace Adms\Controllers;

class VerTipoPg
{
    public function Index(){

    }
}