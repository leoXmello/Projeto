<?php

namespace Adms\Controllers;

class EditarPagina
{
    public function Index(){

    }
}