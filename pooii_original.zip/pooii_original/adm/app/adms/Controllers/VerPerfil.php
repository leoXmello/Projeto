<?php

namespace Adms\Controllers;

class VerPerfil
{
    public function Index(){

    }
}