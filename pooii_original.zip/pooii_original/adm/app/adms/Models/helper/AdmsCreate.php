<?php

namespace Adms\Models\helper;

class AdmsCreate extends AdmsConn
{
    private $Tabela;
    private $Dados;
    private $Query;
    private $Conn;
    private $Resultado;

    public function execCreate($Tabela, array $Dados){
        $this->Tabela = $Tabela;
        $this->Dados = $Dados;

        $colunas = array_keys($this->Dados);


    }

}