<?php
    session_start();
    ob_start(); //Limpa o buffer de redirecionamento

    define('URL', 'http://localhost/projeto_pooii/pooii/');
    define('URLADM', 'http://localhost/projeto_pooii/pooii/adm');

    define('CONTROLLER', 'Home');
    define('METODO', 'index');

    define('HOST', 'localhost');
    define('USER', 'root');
    define('PASS', '');
    define('DBNAME', 'pooii');
    define('PORT', '3307');

