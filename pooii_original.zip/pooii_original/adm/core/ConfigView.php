<?php

namespace Core;

class ConfigView
{
    public $Arquivo;
    public $Dados;

    public function __construct($Arquivo, array $Dados = null){
        $this->Arquivo = (string) $Arquivo;
        $this->Dados = $Dados;
        $this->renderizar();

    }

    public function renderizar(){
        include_once 'app/sts/Views/include/header.php';
        include_once 'app/sts/Views/include/menu.php';
        include_once 'app/sts/Views/include/footer.php';
        if(file_exists('app/sts/Views/' . $this->Arquivo. '.php')){
            include_once 'app/sts/Views/' . $this->Arquivo . '.php';
        }else{
            include_once 'app/sts/Views/include/erro.php';
        }

    }


}