<?php

namespace Core;

class ConfigController
{
    private $Url;
    private $UrlConjunto;
    private $UrlController;
    private $UrlMetodo;
    private $UrlParametro;

    private static $Format;

    public function __construct()
    {
        if (!empty(filter_input(INPUT_GET,'url',FILTER_DEFAULT))){
            $this->Url = filter_input(INPUT_GET,'url',FILTER_DEFAULT);
            $this->limpaurl();
            $this->UrlConjunto = explode("/",$this->Url);

            if (isset($this->UrlConjunto[0])){
                $this->UrlController = $this->slug($this->UrlConjunto[0]);

            }else{
                $this->UrlController = CONTROLLER;

            }

            if(isset($this->UrlController[1])){
                $this->UrlMetodo = $this->slug($this->UrlConjunto[1]);
            }else{
                $this->UrlMetodo = METODO;
            }

            if (isset($this->UrlConjunto[2])){
                $this->UrlParametro = $this->UrlConjunto[2];

            }else{
                $this->UrlParametro = null;


            }

        }else{
            $this->Url = CONTROLLER;
            $this->UrlController = CONTROLLER;
            $this->UrlMetodo = METODO;

        }


        echo "URL: " . $this->Url . "<br>";
        echo "URL Controller: " . $this->UrlController . "<br>";
        echo "URL Método: " . $this->UrlMetodo . "<br>";
        echo "URL Parametro: " . $this->UrlParametro . "<br>";

    }

    private function limpaurl(){
        $this->Url = strip_tags($this->Url);
        $this->Url = trim($this->Url);
        $this->Url = rtrim($this->Url, "/");

        self::$Format = array();
        self::$Format['a'] = 'ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜüÝÞßàáâãäåæçèéêëìíîïðñòóôõöøùúûýýþÿRr"!@#$%&*()_-+={[}]?;:.,\\\'<>°ºª ';
        self::$Format['b'] = 'aaaaaaaceeeeiiiidnoooooouuuuuybsaaaaaaaceeeeiiiidnoooooouuuyybyRr--------------------------------';

        $this->Url = strtr(utf8_decode($this->Url) , utf8_decode(self::$Format['a']), self::$Format['b']);
    }

    private function slugController($slugController){
        $UrlController = strtolower($slugController);
        $UrlController = explode("-",$UrlController);
        $UrlController = implode(" ",$UrlController);
        $UrlController = ucwords($UrlController);
        $UrlController = str_replace(" ","",$UrlController);

        return $UrlController;
    }

    public function carregar(){
        $classe = "\\Adms\\Controllers\\" . $this->UrlController;
        $classeCarregar = new $classe;
        $classeCarregar->index();
    }



}


























