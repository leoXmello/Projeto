<footer class="footer bg-danger">
    <div class="container text-center">
        © copyright 2021 Hotel Plus
    </div>
</footer>

<script src="<?php echo URL;?>assets/js/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="<?php echo URL;?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo URL;?>assets/js/scrollreveal.min.js"></script>


<script>
    window.sr = ScrollReveal({ reset: true });
    sr.reveal('.card-um', {
        duration: 1000,
        origin: 'left',
        distance: '20px'
    });
    sr.reveal('.card-dois', {
        duration: 1000,
        origin: 'bottom',
        distance: '20px'
    });
    sr.reveal('.card-tres', {
        duration: 1000,
        origin: 'right',
        distance: '20px'
    });
    sr.reveal('.video-titulo', {
        duration: 1000,
        origin: 'left',
        distance: '20px'
    });
    sr.reveal('.video-parag', {
        duration: 1000,
        origin: 'right',
        distance: '20px'
    });
    sr.reveal('.video-cont', {
        duration: 1000,
        origin: 'bottom',
        distance: '20px'
    });
    sr.reveal('.art-um', {
        duration: 1000,
        origin: 'bottom',
        distance: '20px'
    });
    sr.reveal('.art-dois', {
        duration: 1000,
        origin: 'bottom',
        distance: '20px'
    });
    sr.reveal('.art-tres', {
        duration: 1000,
        origin: 'bottom',
        distance: '20px'
    });
</script>
</body>
</html>