

<section class="testimonials text-center bg-light">

    <?php

        if (isset($_POST['sub'])){

            $dbHost = 'localhost';
            $dbUsername = 'root';
            $dbSenha = '';
            $dbName = 'pooii';
            $dbPort = '3307';

            $conexao = new mysqli($dbHost, $dbUsername, $dbSenha, $dbName, $dbPort);


            $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
            $check_in = filter_input(INPUT_POST, 'ci', FILTER_SANITIZE_STRING);
            $check_out = filter_input(INPUT_POST, 'co', FILTER_SANITIZE_STRING);
            $opcao = filter_input(INPUT_POST, 'op', FILTER_SANITIZE_NUMBER_INT);

            $resultado = mysqli_query($conexao, "INSERT INTO reserva(nome,check_in,check_out,quarto)VALUE ('$nome','$check_in','$check_out','$opcao')");

            

            
            
            

        };


    ?>
    <div class="container">
        <h2 class="mb-5">FAÇA SUA RESERVA</h2>
        <div id="f1">
            <form method="POST" action="">
                <table<>
                    <tr>
                        <th width="20%" height="50px">Nome</th>
                        <td width="20%" height="50px"><input type="text" name="nome"></td>
                        <th width="20%" height="50px">Check In Data</th>
                        <td width="20%" height="50px"><input type="date" name="ci"></td>
                        <th width="20%" height="50px">Check Out Data</th>
                        <td width="20%" height="50px"><input type="date" name="co"></td>
                        <th width="20%" height="50px">Quarto</th>
                        <td width="20%" height="50px">
                            <select name="op">
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                            </select>
                        </td>
                        <td rowspan="2"><input type="submit" value="Enviar" name="sub"></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</section>
