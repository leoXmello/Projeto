<main role="main">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">


<?php
 $cont = 1;
    foreach ($this->Dados['sts_carousels'] as $carousel){
        extract($carousel);

?>
        <div class="carousel-item <?php if ($cont == 1){echo "active";}?>">
            <img class="first-slide img-fluid" src="<?php echo URL;?>assets/imagens/<?php echo $imagem;?>" alt="<?php echo $titulo;?>">
            <div class="container">
                <div class="carousel-caption <?php echo $posicao_text;?>">
                    <h1 class="d-none d-md-block"><?php echo $titulo;?></h1>
                    <p class="d-none d-md-block"><?php echo $descricao;?></p>
                    <p class="d-none d-md-block"><a class="btn btn-lg btn-danger" href="<?php echo $link;?>" role="button"><?php echo $titulo_botao;?></a></p>
                </div>
            </div>
        </div>
<?php
        $cont++;
    }


?>


        </div>
        <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-6 text-center align-self-center">
                <img src="assets/imagens/mapa.png" class="img-fluid" />
            </div>
            <div class="col-md-6 align-self-center">
                <h2>Nossa Localização</h2>
                <h4>234 West 42nd Street</h4>
                <h4>New York 10036</h4>
                <a href="https://www.google.com.br/maps/place/Anantara+Dhigu+Maldives+Resort/@3.8984569,73.4975514,10.5z/data=!4m22!1m13!4m12!1m4!2m2!1d-46.2378654!2d-22.5281656!4e1!1m6!1m2!1s0x3b3f619bf2465709:0x2cbf39869cff6ed!2sanantara+maldives+location!2m2!1d73.5018157!2d3.9726765!3m7!1s0x3b3f619bf2465709:0x2cbf39869cff6ed!5m2!4m1!1i2!8m2!3d3.9726765!4d73.5018157" class="btn btn-primary button button-primary">Localização</a>
            </div>

        </div>

    </div>
</main>
