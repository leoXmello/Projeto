<?php

namespace Sts\Models;

class sts_carousels
{
    private $Result;

    public function index(){
        $listar = new helper\StsRead();
        $listar->execRead('sts_carousels', "WHERE adms_sit_id=:adms_sit_id LIMIT :limit", ":adms_sit_id=1&:limit=3");
        $this->Result = $listar->getResultado();
        return $this->Result;
    }

}