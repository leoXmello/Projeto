<?php

namespace Sts\Models;

class StsSobre
{
    public function index(){
        $conexao = new helper\StsConn();
        $conexao->getConn();
    }
}