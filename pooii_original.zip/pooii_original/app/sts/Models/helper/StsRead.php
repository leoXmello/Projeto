<?php

namespace Sts\Models\helper;

class StsRead extends StsConn
{
    private $Select;
    private $Values;
    private $Query;
    private $Resultado;
    private $Conn;

    public function getResultado(){
        return $this->Resultado;
    }
    public function execRead($Tabela, $Termos = null, $ParseString = null){
        // SELECT * FROM users WHERE id=:5 LIMIT 1(errado por motivo de segurança)
        // SELECT * FROM users WHERE id=:id LIMIT :limit( correto )
        // $Tabela = users
        // $Termo = WHERE id=:id LIMIT :limit
        // $ParseString = :id=5&:limit=1

        if(!empty($ParseString)){
            parse_str($ParseString, $this->Values);
        }

        $this->Select = "SELECT * FROM $Tabela $Termos";
        $this->execInstrucao();



    }

    private function execInstrucao(){
        $this->preparaConexao();
        $this->linkarValores();
        $this->Query->execute();
        $this->Resultado = $this->Query->fetchAll();


    }

    private function preparaConexao(){
        //conexao
        $this->Conn = parent::getConn();
        $this->Query = $this->Conn->prepare($this->Select);
        $this->Query->setFetchMode(\PDO::FETCH_ASSOC);


    }

    private function linkarValores(){
        if ($this->Values){
            foreach ($this->Values as $a => $b){
                if ($a == ':limit'){
                    $b = (int) $b;
                    $this->Query->bindValue("$a", $b, \PDO::PARAM_INT);
                }else{
                    $this->Query->bindValue("$a", $b, \PDO::PARAM_STR);
                }
            }
        }
    }

}