<?php

namespace Sts\Models;

class StsReserva
{
    public function index(){
        $conexao = new helper\StsConn();
        $conexao->getConn();
    }
}