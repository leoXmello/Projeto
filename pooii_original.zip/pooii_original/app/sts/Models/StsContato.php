<?php

namespace Sts\Models;

class StsContato
{
    public function index(){
        $conexao = new helper\StsConn();
        $conexao->getConn();
    }
}