<?php
namespace Sts\Controllers;
use Core\ConfigView;


if(!defined('URL')){
    header("Location: /pooii_original/pooii");
    exit();
}

class Home
{
    private $Dados;

    public function index(){

        $modelHome = new \Sts\Models\sts_carousels();
        $this->Dados['sts_carousels'] = $modelHome->index();

        $carregarView = new \Core\ConfigView('home/home', $this->Dados);


    }
}