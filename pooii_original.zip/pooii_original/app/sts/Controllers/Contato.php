<?php
namespace Sts\Controllers;

if(!defined('URL')){
    header("Location: /projeto_pooii/pooii");
    exit();
}

class Contato
{

    private $Dados;

    public function index(){

        $modelHome = new \Sts\Models\StsContato();
        $this->Dados = $modelHome->index();

        $carregarView = new \Core\ConfigView('contato/contato', $this->Dados);




    /*public function index(){
        $contato = new \Sts\Models\StsContato();
        $contato->index();

        $carregarView = new \Core\ConfigView('sts/Views/contato/contato');
        $carregarView->renderizar();*/

    }
}