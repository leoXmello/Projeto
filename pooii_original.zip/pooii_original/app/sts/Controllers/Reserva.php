<?php

namespace Sts\Controllers;

if(!defined('URL')){
    header("Location: /projeto_pooii/pooii");
    exit();
}

class Reserva
{

    private $Dados;

    public function index(){

        $modelHome = new \Sts\Models\StsReserva();
        $this->Dados = $modelHome->index();

        $carregarView = new \Core\ConfigView('reserva/reserva', $this->Dados);

        }


}