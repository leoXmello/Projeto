<?php
namespace Sts\Controllers;

if(!defined('URL')){
    header("Location: /projeto_pooii/pooii");
    exit();
}

class SobreEmpresa
{

    private $Dados;

    public function index(){

        $modelHome = new \Sts\Models\StsSobre();
        $this->Dados = $modelHome->index();

        $carregarView = new \Core\ConfigView('sobre/sobre', $this->Dados);







    /*public function index(){
        $sobre = new \Sts\Models\StsSobre();
        $sobre->index();

        $carregarView = new \Core\ConfigView('sts/Views/sobre/sobre');
        $carregarView = new \Core\ConfigView('sobre/sobre', $this->sobre);



        $carregarView->renderizar();*/

    }
}